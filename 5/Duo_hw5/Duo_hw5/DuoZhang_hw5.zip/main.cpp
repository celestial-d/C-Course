//DuoZhangWorker.h
//Duo Zhang
//C++ CIS554
//input and output the alphabet
//main
#include "WordFont.h"
int main()
{
	WordFont myfont;//define a object
	myfont.inputfont();//operate
}