/*
CSE 554 - Employee.cpp
Author: Duo Zhang
Description:
This file is implement file of class employee.
*/#include "Employee.h"


employee::employee()//constructor
{
	SetName(name);//initialize
	SetCoordinates(point);//initialize
}

Point employee::GetCoordinates(Point & pointg)//use to get point
{
	return pointg;
}

void employee::SetCoordinates(Point & points)//usw eto set point
{
	point = points;
}

string employee::GetName(string & nameg)//use to get name
{
	return nameg;
}

void employee::SetName(string & names)//use to set name
{
	name = names;
}





