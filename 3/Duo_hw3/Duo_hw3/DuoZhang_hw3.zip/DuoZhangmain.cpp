//DuoZhangWorker.h
//Duo Zhang
//C++ CIS554
//input and output the salary of different workers
//main function

#include"DuoZhangCAI.h"//basic String library

int main()
{
	CAI student;//define a variable CAI
	student.begin();//operate the program
	return 0;//return
}